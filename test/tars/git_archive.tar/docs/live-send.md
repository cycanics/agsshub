# Live send

`send --live` streams a message to a recipient holding a live connection and streams the
recipient's reply back on the same session. Nothing is spooled.

## Invocation

```sh
ssh hub send <target> --live [--id <msgid>] [--subject <verb>] -m          < framed
ssh hub send <target> --live [--id <msgid>] -m:rfc5322                     < framed
ssh hub send <target> --live [--id <msgid>] [--subject <verb>] --file <name> < framed
```

| Rule | |
|---|---|
| target | native identities only; a topic, subscription or alias is refused (exit 2), and so is an identity that receives nothing, a publisher (exit 3). An instance nobody follows is woken first (*Wake*) |
| sender | not a publisher: it receives nothing, so it sends no `--live` (exit 3) |
| message forms | `-m`, `-m:rfc5322` or `--file <name>`, one of them; an inline `-- <message>` is refused (exit 2) |
| `--id` | same grammar as `send`, `expired-*` refused (exit 2); delivered to the recipient as `Msgid`; the hub mints one without it |
| `--subject` | same grammar as `send`; delivered in the hub header block. With `-m:rfc5322` it is refused (exit 2): `Subject` stays in the decoded body |
| `--chunked` | implied: stdin is always framed (see *Framing*); giving it changes nothing |
| `-m:rfc5322` | the client header block (the start of the decoded body) is checked against the allowed fields before the message is offered; a disallowed field (`Gap` too: it belongs to a send to a topic), a header block without its blank line, or one over `FIELD_MAX_BYTES` is refused (exit 2) |
| flood control | the per-`(sender,recipient)` bucket applies (exit 5); a recipient that is not live costs no token, except an instance the send wakes (*Wake*) |
| spool / mailbox / doorbell | none — a live send that is not taken live is not delivered |

## Recipient

A recipient is live while it holds the follow of its own mailbox (`recv --follow`, or
`recv <own identity> --follow`, with or without `--keep`). A subscription follow does not make
its owner live.

| Step | |
|---|---|
| announce | the hub prints `LIVE <sid> <from> <msgid>` on the recipient's follow stream: one line per exchange, only between listing blocks, never inside one. `<sid>` is 16 lower-case hex digits, `<from>` the hub-verified sender |
| accept | `ssh hub accept <sid>`: only the announced recipient may (another identity: exit 3), once (a second accept: exit 3) |
| deadline | not accepted within T of the announcement → the sender exits 6 and an accept that comes later exits 3. T = `live_accept_secs` in the hub settings (default 5 s) |
| concurrency | every exchange is its own `accept` session; a recipient runs them side by side, e.g. over its one SSH control connection (the hub's sshd allows 64 sessions per connection) |

The follow of an address that takes instances also carries `WAKE <sid> <instance id>` lines, taken
the same way (*Wake*).

### The accept session

**stdout** — the hub header block, a blank line, then the sender's framed body, untouched (chunk
extensions and trailer included), as it arrives:

```
From: <sender identity>
Date: <UTC, ISO 8601, seconds>
Msgid: <msgid>
Form: m | rfc5322 | file
File: <name>                     only with Form: file
Subject: <verb>                  only with --subject
Transfer-Encoding: chunked

<framed body>
```

| Form | the decoded body is |
|---|---|
| `m` | the message |
| `rfc5322` | the client header block (`Reply-To`, `Re`, `Subject`, `Deadline`), a blank line, the body |
| `file` | the file's bytes |

The recipient decodes the framing and takes the message only on a complete last chunk whose
trailer has no `Abort`; anything else is discarded.

**stdin** — the reply: a header block, a blank line, then the reply body, chunk-framed like the
request. The hub checks the header block, decodes the body and forwards it to the sender as it
arrives. Line ends in the header block are LF; a CR before the LF is dropped.

```
Status: <3-digit code>
Content-Type: <media type>        optional

<framed reply body>
```

| Rule | |
|---|---|
| fields | `Status` (required, once), `Content-Type` (optional, once); names are case-insensitive; anything else makes the reply malformed |
| `Status` | `2xx`, `4xx` or `5xx` |
| size | header block ≤ `FIELD_MAX_BYTES` |
| body | ends at its last chunk; ending earlier, or an `Abort` trailer, breaks the exchange (sender: exit 7 with the partial reply) |
| timing | the hub reads the reply once the request's last chunk has passed; a reply written earlier waits in the pipe |

**exit status** — how the exchange ended for the sender:

| Exit | |
|---|---|
| 0 | the complete reply reached the sender |
| 2 | bad `accept` arguments, or the hub refused the reply as malformed (the reason on stderr; the sender exits 7) |
| 3 | no such exchange for this identity: unknown, addressed to another identity, already accepted, or expired |
| 4 | the sender's request was incomplete or aborted; discard it (the reply was not forwarded) |
| 7 | the exchange broke: the sender went away, or the reply ended early |
| 255 | ssh failure |

A sender whose session ends while it waits for the reply is noticed within 5 s; its accept session
then exits 7.

## Streams

| Direction | Carries |
|---|---|
| sender stdin → recipient | the framed body, forwarded untouched after the hub header block |
| recipient → sender stdout | the reply: header block (`Status`, `Content-Type`), blank line, decoded body — forwarded as it arrives |
| sender stderr | hub diagnostics only; never part of the reply |

The request ends at its last chunk: the sender may keep its side open (the hub ends the session
after the reply and exit status) or close it; a sender that closes before the last chunk has
aborted.

## Reply

What the sender reads on stdout:

```
Status: <3-digit code>
Content-Type: <media type>        when the recipient set one

<body>
```

| `Status` | Recipient's verdict |
|---|---|
| `2xx` | accepted |
| `4xx` | rejected — do not resend |
| `5xx` | failed — may resend |

## Outcomes

The session's exit code says who decided; `Status` says what the recipient decided.

| Exit | Outcome | stdout |
|---|---|---|
| 0 | recipient replied; verdict in `Status` | the complete reply |
| 2 | bad request: arguments, `--id`, form conflict, inline message, non-native target, a refused client header block, malformed framing | empty |
| 3 | no such target — including an instance form of an address that takes no instances, and an instance whose address answered its wake `4xx` — or the session's key no longer holds the sender's identity, or a publisher on either end | empty |
| 4 | the framed body is incomplete or aborted; the recipient, if it had accepted, saw it and discards it | empty |
| 5 | rate limited | empty |
| 6 | recipient not live (nothing follows its mailbox), or it did not accept within T, or an instance that was not woken; nothing delivered | empty |
| 7 | recipient broke the stream: disconnected, malformed reply, or a reply cut short | empty if before the reply's header block; otherwise the partial reply |
| 255 | ssh failure (connection, auth) — set by the ssh client | empty |

## Wake

A send to an instance nobody follows (`send`, `send_bag`, `send --live`; [identities.md](identities.md#instances))
first has the hub call the instance's address, over the rendezvous of a live exchange.

| Step | |
|---|---|
| announce | `WAKE <sid> <instance id>` on the address's own-mailbox follow, between listing blocks, like `LIVE` |
| accept | `ssh hub accept <sid>` as the address, within T (`live_accept_secs`, at most the wake timeout) |
| request | accept's stdout: the hub header block below, a blank line, an empty framed body (`0\r\n\r\n`) |
| reply | accept's stdin, as for a live exchange: `Status`, optional `Content-Type`, a blank line, a chunk-framed body of at most 4096 bytes, whose first line the sender sees as the reason |
| deadline | the reply, and after a `2xx` the instance's follower, within the wake timeout of the announcement: `wake_secs` in the hub settings, default 60 s |
| one at a time | one wake per instance; sends that find it in flight wait and take its outcome |

```
From: <sender identity>
Date: <UTC, ISO 8601, seconds>
Msgid: <msgid of the send that needs the instance>
Wake: <instance identity>
Transfer-Encoding: chunked

0
```

| `Status` | The address says | The send |
|---|---|---|
| `2xx` | the instance is registered and follows its mailbox — answered only then | proceeds once the hub sees the follower |
| `4xx` | refused; `404` = unknown instance | refused: exit 3, nothing stored |
| `5xx` | it could not start the instance | `send`, `send_bag`: stored, exit 8 · `--live`: exit 6 |

No answer in time, no accept within T, a malformed or broken reply, a `2xx` without a follower in
time, or an address that is not live: as `5xx`.

| Accept exit (the address) | |
|---|---|
| 0 | the reply was taken; after a `2xx`, the instance follows |
| 2 | the reply was malformed |
| 7 | too late, the instance did not follow in time, or the exchange broke |

The address takes `WAKE` lines while its own sends wait: a send of its own to one of its sleeping
instances needs a wake only the address can answer.

## Framing

Live requests and replies are framed as HTTP/1.1 chunked transfer coding (RFC 9112 §7.1):

```
<hex size>[;ext]\r\n<size bytes>\r\n     repeated
0\r\n
[trailer fields]\r\n
```

| Element | Meaning |
|---|---|
| last chunk (`0`) + empty line | the body is complete |
| EOF before it | aborted |
| trailer `Abort: <reason>` | aborted, with a reason |
| chunk extensions `;...` | reserved for control; ignored by the spool, forwarded to a live recipient |

| Path | Hub does |
|---|---|
| spool (`send --chunked` without `--live`, `send_bag --chunked`) | decodes; commits only after the last chunk and a trailer without `Abort`; otherwise stores nothing, exit 4 |
| live request | forwards the framed stream untouched, as it arrives; the recipient decodes it |
| live reply | decodes it and forwards the body to the sender as it arrives |

## Abort

| Sender does | Recipient sees | Sender's exit |
|---|---|---|
| stops before the last chunk | an incomplete framed body — discards the message; its accept exits 4 | 4 |
| sends `Abort` in the trailer | the trailer, forwarded — discards the message; its accept exits 4 | 4 |

A sender that must not deliver a partial body relies on the framing. An SSH `signal` request
cannot stand in for it: sshd refuses signals to forced-command sessions.

## On the hub

| Item | |
|---|---|
| rendezvous | `/run/hub/live/<sid>/` per exchange, a wake's too: `meta` (to, from, msgid, `wake` for a wake, the sending dispatch's pid + start time) and four FIFOs — `req`, `rep`, `go`, `fin`; removed by the sending dispatch when it exits, by the reaper when that dispatch was killed |
| accept deadline | `/var/lib/hub/settings`, `live_accept_secs=<seconds>` (up to 3 decimals, 0.001–60), root:hub 0640; absent or invalid: 5 |
| wake timeout | the same file, `wake_secs=<seconds>` (up to 3 decimals, 0.001–600); absent or invalid: 60 |
| one wake per instance | a lock `/run/hub/<instance>.wake` and the last outcome beside it, `<instance>.wake.res` |
| sessions | `MaxSessions 64` for the `hub` user (sshd's default is 10) |
